import streamlit as st
import pickle
import re
import pandas as pd
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords

# Download stopwords
@st.cache_resource
def load_stopwords():
    nltk.download('stopwords')
    return stopwords.words('english')

# Load ML model and vectorizer
@st.cache_resource
def load_model_and_vectorizer():
    with open('model.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    with open('vectorizer.pkl', 'rb') as vectorizer_file:
        vectorizer = pickle.load(vectorizer_file)
    return model, vectorizer

# Load Twitter Sentiment140 dataset
@st.cache_data
def load_dataset():
    columns = ['sentiment', 'id', 'date', 'query', 'username', 'text']
    df = pd.read_csv(
        r"C:\Users\user\Downloads\Twitter-Sentiment-Analysis-main  ml\Twitter-Sentiment-Analysis-main\training.1600000.processed.noemoticon.csv",
        encoding="latin-1",
        header=None,
        names=columns
    )
    return df

# Sentiment prediction function
def predict_sentiment(text, model, vectorizer, stop_words):
    text = re.sub('[^a-zA-Z]', ' ', text)
    text = text.lower().split()
    text = [word for word in text if word not in stop_words]
    text = ' '.join(text)
    text = [text]
    text_vector = vectorizer.transform(text)
    sentiment = model.predict(text_vector)[0]
    return "Negative" if sentiment == 0 else "Positive"

# Card for visual sentiment output
def create_card(tweet_text, sentiment):
    color = "green" if sentiment == "Positive" else "red"
    card_html = f"""
    <div style="background-color: {color}; padding: 10px; border-radius: 5px; margin: 10px 0;">
        <h5 style="color: white;">{sentiment} Sentiment</h5>
        <p style="color: white;">{tweet_text}</p>
    </div>
    """
    return card_html

# Streamlit app main logic
def main():
    st.title("Twitter Sentiment Analysis (Dataset-Based)")

    stop_words = load_stopwords()
    model, vectorizer = load_model_and_vectorizer()
    dataset = load_dataset()

    option = st.selectbox("Choose an option", ["Input text", "Get tweets from user"])

    if option == "Input text":
        text_input = st.text_area("Enter text to analyze sentiment")
        if st.button("Analyze"):
            if text_input.strip():
                sentiment = predict_sentiment(text_input, model, vectorizer, stop_words)
                st.write(f"Sentiment: {sentiment}")
            else:
                st.warning("Please enter some text.")

    elif option == "Get tweets from user":
        username = st.text_input("Enter username (case insensitive)")
        if st.button("Fetch Tweets"):
            if username.strip():
                user_tweets = dataset[dataset['username'].str.lower() == username.strip().lower()]
                if not user_tweets.empty:
                    for _, row in user_tweets.head(5).iterrows():
                        tweet_text = row['text']
                        sentiment = predict_sentiment(tweet_text, model, vectorizer, stop_words)
                        card_html = create_card(tweet_text, sentiment)
                        st.markdown(card_html, unsafe_allow_html=True)
                else:
                    st.warning("No tweets found for this username in the dataset.")
            else:
                st.warning("Please enter a username.")

if __name__ == "__main__":
    main()